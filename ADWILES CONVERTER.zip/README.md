# ADWILES CONVERTER - Backend Phase 1

ADWILES CONVERTER adalah platform all-in-one untuk mengonversi, mengolah, mengompres, dan memproses berbagai jenis file. Fase 1 ini berfokus pada pondasi backend yang modular, aman, dan scalable menggunakan Node.js dan Express.js.

## Fitur Tahap 1
- ✅ Health Check API
- ✅ File Upload dengan validasi ketat (MIME, ekstensi, ukuran)
- ✅ JPG → PNG Conversion menggunakan Sharp (Real processing, bukan mock)
- ✅ Secure Download dengan ID unik (mencegah path traversal)
- ✅ Automatic Cleanup (TTL 30 menit untuk file temp dan output)
- ✅ Security Headers (Helmet), CORS, dan Rate Limiting
- ✅ Error Handling global yang konsisten
- ✅ Arsitektur modular (Routes → Controllers → Services → Utils)

## Requirements
- Node.js >= 18.x
- npm atau yarn

## Cara Install & Menjalankan

1. Clone atau buat folder project:
```bash
   mkdir adwiles-converter && cd adwiles-converter
```

2. Buat file `.env` dari `.env.example`:
```bash
   cd backend
   cp .env.example .env
```

3. Install dependencies:
```bash
   npm install
```

4. Jalankan server:
```bash
   # Untuk development (dengan auto-reload)
   npm run dev

   # Untuk production
   npm start
```

Server akan berjalan di `http://localhost:3000`.

## Struktur Project
```text
backend/
├── src/
│   ├── server.js              # Entry point
│   ├── routes/                # Definisi endpoint API
│   ├── controllers/           # Logic request/response
│   ├── services/              # Logic bisnis inti (e.g., Sharp conversion)
│   ├── middleware/            # Upload, error, security
│   └── utils/                 # Helper functions (cleanup, registry, file utils)
├── uploads/                   # (Auto-created)
├── outputs/                   # (Auto-created)
├── temp/                      # (Auto-created)
├── package.json
├── .env.example
└── .gitignore
```

## API Endpoints

### 1. Health Check
- **GET** `/api/health`
- **Response**: `{"success": true, "service": "ADWILES CONVERTER", "status": "online"}`

### 2. Upload File
- **POST** `/api/upload`
- **Content-Type**: `multipart/form-data`
- **Field**: `file` (hanya `.jpg`, `.jpeg`, maks 50MB)
- **Response**: Metadata file yang diupload.

### 3. JPG → PNG Conversion
- **POST** `/api/convert/jpg-to-png`
- **Content-Type**: `multipart/form-data`
- **Field**: `file`
- **Response**: Data konversi dan `downloadUrl`.

### 4. Download Hasil
- **GET** `/api/download/:id`
- **Response**: File `.png` yang diunduh secara aman.

## Cara Testing

### Menggunakan cURL
1. **Health Check**:
```bash
   curl http://localhost:3000/api/health
```
2. **Upload**:
```bash
   curl -X POST http://localhost:3000/api/upload \
     -F "file=@/path/to/your/photo.jpg"
```
3. **Convert JPG to PNG**:
```bash
   curl -X POST http://localhost:3000/api/convert/jpg-to-png \
     -F "file=@/path/to/your/photo.jpg"
```
   *(Salin `downloadUrl` dari response, misal: `/api/download/abc-123`)*
4. **Download**:
```bash
   curl -O http://localhost:3000/api/download/abc-123
```

### Menggunakan Postman
1. Buat request **POST** ke `/api/convert/jpg-to-png`.
2. Pilih tab **Body** → **form-data**.
3. Tambahkan key `file`, ubah tipe dari "Text" menjadi "File".
4. Pilih file `.jpg` dari komputer Anda.
5. Klik **Send**. Salin `downloadUrl` dari response.
6. Buat request **GET** baru, tempel `downloadUrl` (tambahkan `http://localhost:3000` di depannya), dan klik **Send** → **Save to a file**.

## Cara Menambahkan Converter Baru (Scalability)
Arsitektur dirancang agar mudah ditambah tanpa mengubah struktur utama:
1. Buat service baru di `src/services/` (misal: `audio.service.js`).
2. Tambahkan method konversi di dalamnya (misal: `mp3ToWav`).
3. Buat controller di `src/controllers/` yang memanggil service tersebut.
4. Tambahkan route baru di `src/routes/convert.routes.js` (misal: `router.post('/mp3-to-wav', uploadSingle('file'), convertMp3ToWav)`).
5. Tambahkan validasi MIME/ekstensi yang sesuai di `upload.middleware.js` jika diperlukan.

## Security Notes
- **Random Filenames**: Mencegah collision dan eksekusi file berbahaya.
- **No Path Traversal**: Download endpoint menggunakan registry in-memory, bukan input user langsung.
- **TTL Cleanup**: File otomatis dihapus setelah 30 menit untuk menghemat storage.
- **Rate Limiting**: Mencegah abuse pada endpoint API.

## Production Deployment Notes
- Set `NODE_ENV=production`.
- Gunakan reverse proxy seperti Nginx.
- Pastikan folder `uploads`, `outputs`, dan `temp` memiliki permission yang benar.
- Pertimbangkan penggunaan Redis atau Database untuk `registry.utils.js` jika di-deploy secara horizontal (multiple instances).